gcc -fopenmp -std=c99 main.c -o main
